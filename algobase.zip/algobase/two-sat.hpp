#pragma once

#include "class/two-sat.hpp"

/*
@class/two-sat.hpp
*/