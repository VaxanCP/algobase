#pragma once

#include "./class/queue.hpp"

/*
@class/queue.hpp
*/