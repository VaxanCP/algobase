#pragma once
#include "./class/scc.hpp"

/*
@class/scc.hpp
*/