#pragma once

#include "./class/factorial.hpp"

/*
@class/factorial.hpp
*/
