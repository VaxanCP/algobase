#pragma once

#include "./class/vec-series.hpp"

/*
@class/vec-series.hpp
*/