#include <fmt/core.h>
#include <fmt/format.h>
#include <fmt/ranges.h>
#include <immintrin.h>

#include <algorithm>
#include <complex>
#include <iostream>
#include <set>
#include <string>
#include <unordered_map>
#include <unordered_set>

#include "../all.hpp"

int main() {
  std::vector<int> vec;
}
