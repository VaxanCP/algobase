#pragma once

#include <chrono>
#include <ctime>
#include <functional>
#include <iostream>
#include <type_traits>
#define _NANO_SEC  1
#define _MILLI_SEC 2

#pragma GCC optimize("O3")
template <typename _Fn, typename... _Args>
void run_benchmark(int code, _Fn&& fn, _Args&&... args) {
  auto start = std::chrono::steady_clock::now();
  std::invoke(std::forward<_Fn>(fn), std::forward<_Args>(args)...);
  auto end = std::chrono::steady_clock::now();
  if (code & _MILLI_SEC) {
    std::cout << "Result: "
              << std::chrono::duration_cast<std::chrono::milliseconds>(end -
                                                                       start)
                     .count()
              << "ms\n";
  }
  if (code & _NANO_SEC) {
    std::cout << "Result: " << (end - start).count() << "ns\n";
  }
}