#pragma once
#include "./class/poly.hpp"

/*
@class/poly.hpp
*/