#pragma once

#include "./class/series.hpp"

/*
@class/series.hpp
*/