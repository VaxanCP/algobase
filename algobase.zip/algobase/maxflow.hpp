#pragma once

#include "./class/maxflow.hpp"

/*
@class/maxflow.hpp
*/