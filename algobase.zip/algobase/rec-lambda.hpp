#pragma once

#include "./class/rec-lambda.hpp"

/*
@class/rec-lambda.hpp
*/