#pragma once
#include "class/binary-trie.hpp"

/*
@class/binary-trie.hpp
*/