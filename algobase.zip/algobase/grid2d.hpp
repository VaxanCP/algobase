#pragma once

#include "./class/grid2d.hpp"

/*
@class/grid2d.hpp
*/