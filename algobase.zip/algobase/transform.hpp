#pragma once

#include <cassert>
#include <span>
#include <vector>

#include "./internal/base/typing.hpp"
#include "./numeric.hpp"
/*
@numeric.hpp
@internal/base/typing.hpp
*/
// makecode
namespace algo {
/**
 * \brief Compute zeta[i] = sum(f[d] for d | i) for each i = 1, 2, 3, ...n where
 * n = size(f) - 1. Note that we consider f[i] as one-based indexing.
 *
 * \tparam Tp must have operator+
 * \param f f.size() > 1 required.
 * \return
 */
template <std::semiregular Tp>
std::vector<Tp> divisor_zeta(std::vector<Tp> f) {
#if !defined(NDEBUG)
  assert(f.size() > 1);
#endif
  const int n = static_cast<int>(f.size()) - 1;
  for (const int p : enumerate_primes(n)) {
    for (int k = 1; k * p <= n; ++k) { f[k * p] += f[k]; }
  }
  return f;
}
/**
 * \brief Return
 *
 * \tparam Tp
 * \param f
 * \return
 */
template <std::semiregular Tp>
std::vector<Tp> multiple_zeta(std::vector<Tp> f) {
#if !defined(NDEBUG)
  assert(f.size() > 1);
#endif
  const int n = static_cast<int>(f.size()) - 1;
  for (const int p : enumerate_primes(n)) {
    for (int k = n / p; k > 0; --k) { f[k] += f[k * p]; }
  }
  return f;
}
}  // namespace algo