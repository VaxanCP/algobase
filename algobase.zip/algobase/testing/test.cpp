#include <iostream>
#include <random>

#include "../modular.hpp"
#define FLAG 1
constexpr uint32_t MOD = 998244353;

uint32_t inverse(uint32_t n) {
#if FLAG
  return algo::pow_mod(n, MOD - 2, MOD);
#else
  return algo::inv_mod(n, MOD);
#endif
}

int main() {
  const int tests = 10000000;
  std::mt19937 rng;
  std::uniform_int_distribution dist(1u, MOD);
  uint32_t sum = 0;
  for (int i = 0; i < tests; ++i) {
    const auto n = dist(rng);
    sum += inverse(n);
  }
  std::cout << sum << '\n';
}