#pragma once

#include "./class/sieve.hpp"

/*
@class/sieve.hpp
*/