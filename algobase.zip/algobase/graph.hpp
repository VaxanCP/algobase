#pragma once
#include "./class/graph.hpp"

/*
@class/graph.hpp
*/