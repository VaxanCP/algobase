#pragma GCC target("abm,movbe,bmi,bmi2,lzcnt,popcnt")
#pragma GCC target("f16c,fma,avx2")
#include <cassert>
#include <iostream>
#include <random>
#include <vector>

#include "../convolution.hpp"
#include "../modint.hpp"

using algo::modint;
using algo::poly;

template <int32_t MOD>
void generate_testcase(size_t n) {
  std::mt19937 rnd;
  std::uniform_int_distribution dist(0, MOD - 1);
  std::vector<modint<MOD>> src(n);
  std::generate(src.begin(), src.end(),
                [&] { return modint<MOD>::from(dist(rnd)); });
  poly<MOD> f1 = src, f2 = std::move(src);
  std::cout << "Start processing for N = " << n << " with MOD = " << MOD
            << "..\n";
  f2 *= f2;
  std::cout << "Ok. Processing completed successfully.\n";
  std::cout << "Generating testcases for N = " << n << "...\n";
  float progress = 0.0f;
  constexpr int test_size = 2000;
  constexpr float step = 1.f / test_size;
  constexpr int bar_width = 60;
  for (int i = 0; i < test_size; ++i) {
    const int pos = static_cast<int>(bar_width * progress);
    std::cout << '[';
    for (int j = 0; j < bar_width; ++j) {
      if (j < pos) {
        std::cout << '#';
      } else if (j == pos) {
        std::cout << '>';
      } else {
        std::cout << ' ';
      }
    }
    std::cout << ']' << static_cast<int>(progress * 100.f) << "%"
              << "Completed\r";
    std::cout.flush();
    const auto c = f1(i);
    assert(c * c == f2(i));
    progress += step;
  }
  std::cout << std::endl;
  std::cout << "Ok. All correct!\n";
}

int main() {
  constexpr int N = 100000;
  constexpr int MOD = 998244353;
  std::cout.sync_with_stdio(false);
  std::cout.tie(nullptr);
  generate_testcase<998244353>(100000);
  std::cout << '\n';
  generate_testcase<1000000007>(100000);
  std::cout << '\n';
  return 0;
}
