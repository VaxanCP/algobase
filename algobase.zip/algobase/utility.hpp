#pragma once
#include <algorithm>
#include <cassert>
#include <numeric>
#include <utility>
#include <vector>
// modules
#include "internal/base/def.hpp"
#include "internal/base/typing.hpp"
/*
@internal/base/typing.hpp
@internal/base/def.hpp
*/
// makecode
namespace algo {
/**
 * \brief Return vector p[0..n-1] where p[i]=j means that v[j] would be in
 * ith index when sorted
 *
 * \tparam Tp
 * \tparam Compare
 * \param vec
 * \param comp
 * \return std::vector<int>
 */
template <typename Tp, std::strict_weak_order<Tp, Tp> Compare = std::less<Tp>>
std::vector<int> argsort(const std::vector<Tp> &vec, Compare comp = {}) {
  std::vector<int> ind(vec.size());
  std::iota(ind.begin(), ind.end(), 0);
  std::sort(ind.begin(), ind.end(),
            [&](int a, int b) -> bool { return comp(vec[a], vec[b]); });
  return ind;
}
template <typename Tp, std::strict_weak_order<Tp, Tp> Compare = std::less<Tp>>
std::vector<int> stable_argsort(const std::vector<Tp> &vec, Compare comp = {}) {
  std::vector<int> ind(vec.size());
  std::iota(ind.begin(), ind.end(), 0);
  std::stable_sort(ind.begin(), ind.end(),
                   [&](int a, int b) -> bool { return comp(vec[a], vec[b]); });
  return ind;
}
template <typename Tp, std::strict_weak_order<Tp, Tp> Compare = std::less<Tp>>
std::vector<Tp> sort_unique_erase(std::vector<Tp> out, Compare comp = {}) {
  std::sort(out.begin(), out.end(), std::move(comp));
  out.erase(std::unique(out.begin(), out.end()), out.end());
  return out;
}
/**
 * \brief
 *
 * \param perm
 * \return std::vector<int>
 */
std::vector<int> inverse(const std::vector<int> &perm) {
  std::vector<int> out(perm.size());
  for (int i = 0; i < std::ssize(perm); ++i) { out[perm[i]] = i; }
  return out;
}
/**
 * \brief Permute given vector such that result[perm[i]] = vec[i] for each
 * i in [0,n) hold
 *
 * \tparam Tp
 * \param vec
 * \param perm
 * \return
 */
template <std::semiregular Tp>
std::vector<Tp> permute(const std::vector<Tp> &vec,
                        const std::vector<int> &perm) {
#if !defined(NDEBUG)
  assert(vec.size() == perm.size());
#endif
  std::vector<Tp> out(vec.size());
  for (int i = 0; i < std::ssize(vec); ++i) { out[perm[i]] = vec[i]; }
  return out;
}
template <typename Tp, std::strict_weak_order<Tp, Tp> Compare = std::less<Tp>>
std::vector<int> compress(const std::vector<Tp> &vec, Compare comp = {}) {
  std::vector<int> ind = argsort(vec, std::move(comp));
  std::vector<int> out(vec.size());
  for (int i = 0, c = 0; i < std::ssize(vec); ++c) {
    int j = i;
    do {
      out[ind[j]] = c;
    } while (++j < std::ssize(vec) && !comp(vec[ind[j]], vec[ind[i]]) &&
             !comp(vec[ind[i]], vec[ind[j]]));
    i = j;
  }
  return out;
}
}  // namespace algo