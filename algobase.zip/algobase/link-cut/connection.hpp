#pragma once

#include "../class/lct/connection.hpp"

/*
@class/lct/connection.hpp
*/