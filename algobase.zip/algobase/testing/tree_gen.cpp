#include <immintrin.h>

#include <algorithm>
#include <fstream>
#include <iostream>
#include <queue>
#include <random>
#include <set>
#include <vector>

#include "../sparse-table.hpp"

int main() {
  using std::vector;
  using min_heap = std::priority_queue<int, vector<int>, std::greater<int>>;
  const int ts = 1;
  std::ofstream file("/home/naota/Documents/CP/codes/tree_tests",
                     std::ios::trunc);
  file << ts << '\n';
  std::mt19937 seed;
  std::uniform_int_distribution dist(1, 200001);
  for (int t = 0; t < ts; ++t) {
    std::cout << t / 10.f << "% completed\n";
    const int n = dist(seed) + 2;
    file << n << '\n';
    std::uniform_int_distribution vdist(0, n - 1);
    vector<int> seq(n - 2);
    vector<int> deg(n);
    for (int i = 0; i < n - 2; ++i) {
      seq[i] = vdist(seed);
      deg[seq[i]]++;
    }
    min_heap pq;
    for (int i = 0; i < n; ++i) {
      deg[i]++;
      if (deg[i] == 1) { pq.push(i); }
    }
    for (int i = 0; i < n - 2; ++i) {
      int j = pq.top();
      pq.pop();
      file << seq[i] + 1 << ' ' << j + 1 << '\n';
      if (--deg[seq[i]] == 1) { pq.push(seq[i]); }
    }
    int u = pq.top();
    pq.pop();
    file << n << ' ' << u + 1 << '\n';
  }
  return 0;
}